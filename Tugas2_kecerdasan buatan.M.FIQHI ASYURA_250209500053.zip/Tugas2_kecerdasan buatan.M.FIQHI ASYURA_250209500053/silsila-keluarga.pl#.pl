pria(nola).
pria(djasri).
pria(takbir).
pria(ipung).
pria(rinal).
pria(fiqhi).
pria(bendi).
pria(andiko).

wanita(nenang).
wanita(murtinah).
wanita(marzidah).
wanita(dwi).
wanita(rezky).

pasangan(nola, nenang).
pasangan(djasri, murtinah).
pasangan(takbir, marzidah).
pasangan(ipung, dwi).

orangtua(nola, takbir).
orangtua(nenang, takbir).

orangtua(djasri, marzidah).
orangtua(murtinah, marzidah).
orangtua(djasri, ipung).
orangtua(murtinah, ipung).

orangtua(takbir, rezky).
orangtua(marzidah, rezky).
orangtua(takbir, rinal).
orangtua(marzidah, rinal).
orangtua(takbir, fiqhi).
orangtua(marzidah, fiqhi).

orangtua(ipung, bendi).
orangtua(dwi, bendi).
orangtua(ipung, andiko).
orangtua(dwi, andiko).

ayah(X, Y) :- orangtua(X, Y), pria(X).
ibu(X, Y) :- orangtua(X, Y), wanita(X).

suami(X, Y) :- pasangan(X, Y).
istri(Y, X) :- pasangan(X, Y).

anak(Y, X) :- orangtua(X, Y).

kakek(X, Y) :- orangtua(X, Z), orangtua(Z, Y), pria(X).
nenek(X, Y) :- orangtua(X, Z), orangtua(Z, Y), wanita(X).

cucu(Y, X) :- kakek(X, Y).
cucu(Y, X) :- nenek(X, Y).

saudara(X, Y) :-
    orangtua(P, X),
    orangtua(P, Y),
    X \= Y.

paman(X, Y) :-
    orangtua(P, Y),
    saudara(X, P),
    pria(X).

bibi(X, Y) :-
    orangtua(P, Y),
    saudara(X, P),
    wanita(X).

sepupu(X, Y) :-
    orangtua(P1, X),
    orangtua(P2, Y),
    saudara(P1, P2).



















